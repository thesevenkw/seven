package com.saludocupacional.sooma.servicio.impl;


import com.saludocupacional.sooma.modelo.Turno;
import com.saludocupacional.sooma.repositorio.ICrudGenericoRepository;
import com.saludocupacional.sooma.repositorio.TurnoRepository;
import com.saludocupacional.sooma.servicio.TurnoService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@Transactional
@RequiredArgsConstructor
public class TurnoServiceImp extends CrudGenericoServiceImp <Turno, Long> implements TurnoService {
    private final TurnoRepository repo;

    @Override
    protected ICrudGenericoRepository<Turno, Long> getRepo() { return repo; }

    public Page<Turno> listaPage(Pageable pageable) {
        return repo.findAll(pageable);
    }
}
