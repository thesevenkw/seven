package com.saludocupacional.sooma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoomaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoomaApplication.class, args);
	}

}
