package com.saludocupacional.sooma.servicio.impl;

import com.saludocupacional.sooma.dtos.PersonalDTO;
import com.saludocupacional.sooma.mappers.PersonalMapper;
import com.saludocupacional.sooma.modelo.Cargo;
import com.saludocupacional.sooma.modelo.Personal;
import com.saludocupacional.sooma.modelo.Turno;
import com.saludocupacional.sooma.repositorio.CargoRepository;
import com.saludocupacional.sooma.repositorio.ICrudGenericoRepository;
import com.saludocupacional.sooma.repositorio.PersonalRepository;
import com.saludocupacional.sooma.repositorio.TurnoRepository;
import com.saludocupacional.sooma.servicio.PersonalService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@Transactional
@RequiredArgsConstructor
public class PersonalServiceImp extends CrudGenericoServiceImp <Personal, Long> implements PersonalService {
    private final PersonalRepository repo;

    @Override
    protected ICrudGenericoRepository<Personal, Long> getRepo() { return repo; }
}
