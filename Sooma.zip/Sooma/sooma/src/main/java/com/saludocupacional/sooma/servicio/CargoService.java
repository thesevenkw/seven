package com.saludocupacional.sooma.servicio;

import com.saludocupacional.sooma.modelo.Cargo;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface CargoService extends ICrudGenericoService<Cargo, Long> {

}
