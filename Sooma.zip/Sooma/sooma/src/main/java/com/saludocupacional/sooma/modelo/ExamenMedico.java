package com.saludocupacional.sooma.modelo;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "sooma_examenMedico")
public class ExamenMedico {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_examenMedico")
    private Long idExamenMedico;
    @Column(name = "resultado", nullable = false, length = 50)
    private String resultado;
    @Column(name = "observaciones", nullable = false, length = 50)
    private String observaciones;
    @Column(name = "trabajador", nullable = false, length = 50)
    private String trabajador;
    @Column(name = "personal", nullable = false, length = 50)
    private String personal;
}
