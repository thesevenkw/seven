package com.saludocupacional.sooma.repositorio;

import com.saludocupacional.sooma.modelo.ExamenMedico;

public interface ExamenMedicoRepository extends ICrudGenericoRepository<ExamenMedico, Long> {
}
