package com.saludocupacional.sooma.control;

import com.saludocupacional.sooma.dtos.PersonalDTO;
import com.saludocupacional.sooma.dtos.PersonalDTO;
import com.saludocupacional.sooma.mappers.PersonalMapper;
import com.saludocupacional.sooma.mappers.PersonalMapper;
import com.saludocupacional.sooma.modelo.Personal;
import com.saludocupacional.sooma.modelo.Personal;
import com.saludocupacional.sooma.servicio.PersonalService;
import com.saludocupacional.sooma.servicio.PersonalService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/personales")
@CrossOrigin("*")
public class PersonalController {
    private final PersonalService servicekr;
    private final PersonalMapper mapperkr;
    @GetMapping
    public ResponseEntity<List<PersonalDTO>> findAll() {
        List<PersonalDTO> list = mapperkr.toDTOs(servicekr.findAll());
        return ResponseEntity.ok(list);
    }
    @GetMapping("/{id}")
    public ResponseEntity<PersonalDTO> findById(@PathVariable("id") Long id) {
        Personal obj = servicekr.findById(id);
        return ResponseEntity.ok(mapperkr.toDTO(obj));
    }
    @PostMapping
    public ResponseEntity<Void> save(@Valid @RequestBody PersonalDTO dto) {
        Personal obj = servicekr.save(mapperkr.toEntity(dto));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdPersonal()).toUri();
        return ResponseEntity.created(location).build();
    }
    @PutMapping("/{id}")
    public ResponseEntity<PersonalDTO> update(@Valid @PathVariable("id") Long id, @RequestBody PersonalDTO dto) {
        dto.setIdPersonal(id);
        Personal obj = servicekr.update(id, mapperkr.toEntity(dto));
        return ResponseEntity.ok(mapperkr.toDTO(obj));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") Long id) {
        servicekr.delete(id);
        return ResponseEntity.noContent().build();
    }
}
