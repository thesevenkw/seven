package com.saludocupacional.sooma.mappers;

import com.saludocupacional.sooma.dtos.PersonalDTO;
import com.saludocupacional.sooma.modelo.Personal;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;


@Mapper(componentModel = "spring")
public interface PersonalMapper extends GenericMapper<PersonalDTO, Personal> {

}
