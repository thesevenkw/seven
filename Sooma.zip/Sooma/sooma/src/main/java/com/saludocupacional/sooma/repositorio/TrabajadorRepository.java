package com.saludocupacional.sooma.repositorio;

import com.saludocupacional.sooma.modelo.Trabajador;

public interface TrabajadorRepository extends ICrudGenericoRepository<Trabajador, Long>{
}
