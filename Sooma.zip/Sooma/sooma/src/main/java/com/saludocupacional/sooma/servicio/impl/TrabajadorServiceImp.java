package com.saludocupacional.sooma.servicio.impl;

import com.saludocupacional.sooma.dtos.TrabajadorDTO;
import com.saludocupacional.sooma.mappers.TrabajadorMapper;
import com.saludocupacional.sooma.modelo.Cargo;
import com.saludocupacional.sooma.modelo.Trabajador;
import com.saludocupacional.sooma.repositorio.CargoRepository;
import com.saludocupacional.sooma.repositorio.ICrudGenericoRepository;
import com.saludocupacional.sooma.repositorio.TrabajadorRepository;
import com.saludocupacional.sooma.servicio.TrabajadorService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@Transactional
@RequiredArgsConstructor
public class TrabajadorServiceImp extends CrudGenericoServiceImp<Trabajador, Long> implements TrabajadorService {

    private final TrabajadorRepository repo;

    @Override
    protected ICrudGenericoRepository<Trabajador, Long> getRepo() { return repo; }
}

