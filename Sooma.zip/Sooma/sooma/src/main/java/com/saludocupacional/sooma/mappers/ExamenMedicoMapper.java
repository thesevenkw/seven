package com.saludocupacional.sooma.mappers;

import com.saludocupacional.sooma.dtos.ExamenMedicoDTO;
import com.saludocupacional.sooma.modelo.ExamenMedico;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ExamenMedicoMapper extends  GenericMapper<ExamenMedicoDTO, ExamenMedico> {
}
