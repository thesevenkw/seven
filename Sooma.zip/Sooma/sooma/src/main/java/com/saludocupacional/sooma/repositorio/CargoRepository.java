package com.saludocupacional.sooma.repositorio;

import com.saludocupacional.sooma.modelo.Cargo;

public interface CargoRepository extends ICrudGenericoRepository<Cargo, Long>{
}
