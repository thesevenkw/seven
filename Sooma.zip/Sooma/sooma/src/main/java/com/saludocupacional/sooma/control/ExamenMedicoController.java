package com.saludocupacional.sooma.control;

import com.saludocupacional.sooma.dtos.ExamenMedicoDTO;
import com.saludocupacional.sooma.mappers.ExamenMedicoMapper;
import com.saludocupacional.sooma.modelo.ExamenMedico;

import com.saludocupacional.sooma.servicio.ExamenMedicoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;
@RequiredArgsConstructor
@RestController
@RequestMapping("/examenmedicos")
@CrossOrigin("*")
public class ExamenMedicoController {
    private final ExamenMedicoService servicekr;
    private final ExamenMedicoMapper mapperkr;
    @GetMapping
    public ResponseEntity<List<ExamenMedicoDTO>> findAll() {
        List<ExamenMedicoDTO> list = mapperkr.toDTOs(servicekr.findAll());
        return ResponseEntity.ok(list);
    }
    @GetMapping("/{id}")
    public ResponseEntity<ExamenMedicoDTO> findById(@PathVariable("id") Long id) {
        ExamenMedico obj = servicekr.findById(id);
        return ResponseEntity.ok(mapperkr.toDTO(obj));
    }
    @PostMapping
    public ResponseEntity<Void> save(@Valid @RequestBody ExamenMedicoDTO dto) {
        ExamenMedico obj = servicekr.save(mapperkr.toEntity(dto));
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdExamenMedico()).toUri();
        return ResponseEntity.created(location).build();
    }
    @PutMapping("/{id}")
    public ResponseEntity<ExamenMedicoDTO> update(@Valid @PathVariable("id") Long id, @RequestBody ExamenMedicoDTO dto) {
        dto.setIdExamenMedico(id);
        ExamenMedico obj = servicekr.update(id, mapperkr.toEntity(dto));
        return ResponseEntity.ok(mapperkr.toDTO(obj));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") Long id) {
        servicekr.delete(id);
        return ResponseEntity.noContent().build();
    }
}
