package com.saludocupacional.sooma.mappers;

import com.saludocupacional.sooma.dtos.TurnoDTO;
import com.saludocupacional.sooma.modelo.Turno;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface TurnoMapper extends GenericMapper<TurnoDTO, Turno> {
}
