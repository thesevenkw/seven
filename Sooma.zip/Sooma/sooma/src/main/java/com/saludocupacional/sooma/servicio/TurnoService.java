package com.saludocupacional.sooma.servicio;

import com.saludocupacional.sooma.modelo.Turno;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface TurnoService extends ICrudGenericoService <Turno, Long> {

}
