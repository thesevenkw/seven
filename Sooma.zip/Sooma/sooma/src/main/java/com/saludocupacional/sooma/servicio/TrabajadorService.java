package com.saludocupacional.sooma.servicio;

import com.saludocupacional.sooma.dtos.TrabajadorDTO;
import com.saludocupacional.sooma.modelo.Trabajador;


public interface TrabajadorService extends ICrudGenericoService<Trabajador, Long> {

}
