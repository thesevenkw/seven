package com.saludocupacional.sooma.dtos;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
@NoArgsConstructor
@AllArgsConstructor
@Data
public class TrabajadorDTO {
    private Long idTrabajador;
    @NotNull(message = "El nombre no puede ser nulo")
    private String nombre;
    @NotNull(message = "El apellido no puede ser nulo")
    private String apellido;
    @NotNull(message = "El dni no puede ser nulo")
    private String dni;
    @NotNull(message = "El celular no puede ser nulo")
    private String celular;
    @NotNull(message = "El cargo no puede ser nulo")
    private String cargo;

}
