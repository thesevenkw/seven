package com.saludocupacional.sooma.dtos;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class PersonalDTO {
    private Long idPersonal;
    @NotNull(message = "El nombre no puede ser nula")
    private String nombre;
    @NotNull(message = "El apellido no puede ser nula")
    private String apellido;
    @NotNull(message = "El especialidad no puede ser nula")
    private String especialidad;
    @NotNull(message = "El turno no puede ser nula")
    private String turno;

}
