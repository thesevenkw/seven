package com.saludocupacional.sooma.servicio.impl;

import com.saludocupacional.sooma.modelo.Cargo;
import com.saludocupacional.sooma.repositorio.CargoRepository;
import com.saludocupacional.sooma.repositorio.ICrudGenericoRepository;
import com.saludocupacional.sooma.servicio.CargoService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@Transactional
@RequiredArgsConstructor
public class CargoServiceImp extends CrudGenericoServiceImp<Cargo, Long> implements CargoService {
    private final CargoRepository repo;

    @Override
    protected ICrudGenericoRepository<Cargo, Long> getRepo() { return repo; }

}
