package com.saludocupacional.sooma.servicio;

import com.saludocupacional.sooma.dtos.PersonalDTO;
import com.saludocupacional.sooma.modelo.Personal;


public interface PersonalService extends ICrudGenericoService<Personal, Long> {

}
