package com.saludocupacional.sooma.repositorio;

import com.saludocupacional.sooma.modelo.Personal;

public interface PersonalRepository extends ICrudGenericoRepository<Personal, Long> {
}
