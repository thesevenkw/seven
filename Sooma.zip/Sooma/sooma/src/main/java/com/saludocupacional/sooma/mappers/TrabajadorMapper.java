package com.saludocupacional.sooma.mappers;

import com.saludocupacional.sooma.dtos.TrabajadorDTO;
import com.saludocupacional.sooma.modelo.Trabajador;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface TrabajadorMapper extends GenericMapper<TrabajadorDTO, Trabajador> {
}
