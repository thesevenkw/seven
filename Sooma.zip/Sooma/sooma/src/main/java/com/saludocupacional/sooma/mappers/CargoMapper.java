package com.saludocupacional.sooma.mappers;

import com.saludocupacional.sooma.dtos.CargoDTO;
import com.saludocupacional.sooma.modelo.Cargo;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface CargoMapper extends GenericMapper<CargoDTO, Cargo> {
}
