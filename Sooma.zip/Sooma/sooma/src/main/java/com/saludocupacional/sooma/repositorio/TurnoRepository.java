package com.saludocupacional.sooma.repositorio;

import com.saludocupacional.sooma.dtos.TurnoDTO;
import com.saludocupacional.sooma.mappers.GenericMapper;
import com.saludocupacional.sooma.modelo.Turno;
import org.mapstruct.Mapper;


public interface TurnoRepository extends ICrudGenericoRepository<Turno, Long> {

}
