package com.saludocupacional.sooma.dtos;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
@NoArgsConstructor
@AllArgsConstructor
@Data
public class ExamenMedicoDTO {
    private Long idExamenMedico;
    @NotNull(message = "El resultado no puede ser nulo")
    private String resultado;
    @NotNull(message = "El observaciones no puede ser nulo")
    private String observaciones;
    @NotNull(message = "El trabajador no puede ser nulo")
    private String trabajador;
    @NotNull(message = "El personal no puede ser nulo")
    private String personal;

}
