package com.saludocupacional.sooma.servicio.impl;


import com.saludocupacional.sooma.modelo.ExamenMedico;
import com.saludocupacional.sooma.modelo.Personal;
import com.saludocupacional.sooma.modelo.Trabajador;
import com.saludocupacional.sooma.repositorio.*;
import com.saludocupacional.sooma.servicio.ExamenMedicoService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@Transactional
@RequiredArgsConstructor
public class ExamenMedicoServiceImp extends CrudGenericoServiceImp<ExamenMedico, Long> implements ExamenMedicoService {
    private final ExamenMedicoRepository repo;

    @Override
    protected ICrudGenericoRepository<ExamenMedico, Long> getRepo() { return repo; }


}
