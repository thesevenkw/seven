package com.saludocupacional.sooma.servicio;

import com.saludocupacional.sooma.dtos.ExamenMedicoDTO;
import com.saludocupacional.sooma.modelo.ExamenMedico;
import com.saludocupacional.sooma.repositorio.ICrudGenericoRepository;

public interface ExamenMedicoService extends ICrudGenericoService<ExamenMedico, Long> {

}
