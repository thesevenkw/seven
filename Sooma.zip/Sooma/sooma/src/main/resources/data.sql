-- Insertar datos en la tabla sooma_cargo
INSERT INTO sooma_cargo (id_cargo, nombre_cargo) VALUES
                                                     (1, 'Gerente'),
                                                     (2, 'Supervisor'),
                                                     (3, 'Operario'),
                                                     (4, 'Técnico'),
                                                     (5, 'Administrativo');

-- Insertar datos en la tabla sooma_turno
INSERT INTO sooma_turno (id_turno, nombre) VALUES
                                               (1, 'Mañana'),
                                               (2, 'Tarde'),
                                               (3, 'Noche');

-- Insertar datos en la tabla sooma_personal
INSERT INTO sooma_personal (id_personal, apellido, especialidad, nombre, turno) VALUES
                                                                                    (1, 'Pérez', 'Medicina general', 'Juan', 'Mañana'),
                                                                                    (2, 'Gomez', 'Cardiología', 'Ana', 'Tarde'),
                                                                                    (3, 'Rodriguez', 'Oftalmología', 'Luis', 'Mañana');

-- Insertar datos en la tabla sooma_trabajador
INSERT INTO sooma_trabajador (id_trabajador, apellido, cargo, celular, dni, nombre) VALUES
                                                                                        (1, 'Lopez', 'Operario', '987654321', '76543210', 'Pedro'),
                                                                                        (2, 'Martinez', 'Técnico', '912345678', '87654321', 'Maria'),
                                                                                        (3, 'Sanchez', 'Supervisor', '956789012', '43210987', 'Jose');

-- Insertar datos en la tabla sooma_examen_medico
INSERT INTO sooma_examen_medico (id_examen_medico, observaciones, personal, resultado, trabajador) VALUES
                                                                                                       (1, 'Sin observaciones', 'Juan Pérez', 'Apto', 'Pedro Lopez'),
                                                                                                       (2, 'Necesita lentes', 'Luis Rodriguez', 'Apto con restricciones', 'Maria Martinez'),
                                                                                                       (3, 'Presión arterial alta', 'Ana Gomez', 'No apto', 'Jose Sanchez');