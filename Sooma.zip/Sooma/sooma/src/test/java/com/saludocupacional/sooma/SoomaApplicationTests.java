package com.saludocupacional.sooma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoomaApplicationTests {

	@Test
	void contextLoads() {
	}

}
