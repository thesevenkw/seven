import { Routes } from '@angular/router';
import {MainCargoComponent} from "./main-cargo/main-cargo.component";
import {FormCargoComponent} from "./main-cargo/form-cargo/form-cargo.component";
import {MainExamenMedicoComponent} from "./main-examen-medico/main-examen-medico.component";
import {FormExamenMedicoComponent} from "./main-examen-medico/form-examen-medico/form-examen-medico.component";
import {MainPersonalComponent} from "./main-personal/main-personal.component";
import {FormPersonalComponent} from "./main-personal/form-personal/form-personal.component";
import {MainTrabajadorComponent} from "./main-trabajador/main-trabajador.component";
import {FormTrabajadorComponent} from "./main-trabajador/form-trabajador/form-trabajador.component";
import {MainTurnoComponent} from "./main-turno/main-turno.component";
import {FormTurnoComponent} from "./main-turno/form-turno/form-turno.component";

export const pagesRoutes: Routes = [
  {
    path: 'cargo',
    component: MainCargoComponent,
    children: [
      { path: 'new', component: FormCargoComponent },
      { path: 'edit/:id', component: FormCargoComponent },
    ],
  },
  {
    path: 'examenmedico',
    component: MainExamenMedicoComponent,
    children: [
      { path: 'new', component: FormExamenMedicoComponent },
      { path: 'edit/:id', component: FormExamenMedicoComponent },
    ],
  },
  {
    path: 'personal',
    component: MainPersonalComponent,
    children: [
      { path: 'new', component: FormPersonalComponent },
      { path: 'edit/:id', component: FormPersonalComponent },
    ],
  },
  {
    path: 'trabajador',
    component: MainTrabajadorComponent,
    children: [
      { path: 'new', component: FormTrabajadorComponent },
      { path: 'edit/:id', component: FormTrabajadorComponent },
    ],
  },
  {
    path: 'turno',
    component: MainTurnoComponent,
    children: [
      { path: 'new', component: FormTurnoComponent },
      { path: 'edit/:id', component: FormTurnoComponent },
    ],
  },

];
