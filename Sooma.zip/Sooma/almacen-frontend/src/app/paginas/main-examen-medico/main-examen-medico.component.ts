import {Component, OnInit, ViewChild} from '@angular/core';
import {MatTableDataSource} from "@angular/material/table";
import {MatPaginator} from "@angular/material/paginator";
import {MatSort} from "@angular/material/sort";
import {MatSnackBar} from "@angular/material/snack-bar";
import {MatDialog} from "@angular/material/dialog";
import {switchMap} from "rxjs";
import {RouterLink, RouterOutlet} from "@angular/router";
import {MaterialModule} from "../../material/material.module";
import {ExamenMedico} from "../../modelo/ExamenMedico";
import {FormExamenMedicoComponent} from "./form-examen-medico/form-examen-medico.component";
import {ExamenMedicoService} from "../../servicio/examen-medico.service";

@Component({
  selector: 'app-main-examen-medico',
  standalone: true,
  imports: [MaterialModule, RouterOutlet, RouterLink],
  templateUrl: './main-examen-medico.component.html',
  styleUrl: './main-examen-medico.component.css'
})
export class MainExamenMedicoComponent implements OnInit {
  dataSource: MatTableDataSource<ExamenMedico>;
  columnsDefinitions = [
    { def: 'idExamenMedico', label: 'idExamenMedico', hide: true},
    { def: 'resultado', label: 'resultado', hide: false},
    { def: 'observaciones', label: 'observaciones', hide: false},
    { def: 'trabajador', label: 'trabajador', hide: false},
    { def: 'personal', label: 'personal', hide: false},
    { def: 'acciones', label: 'acciones', hide: false}
  ];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  constructor(
    private krervice: ExamenMedicoService,
    private _dialog: MatDialog,
    private _snackBar: MatSnackBar
  ){}
  ngOnInit(): void {
    this.krervice.findAll().subscribe(data => this.createTable(data));

    this.krervice.getExamenMedicoChange().subscribe(data => this.createTable(data));
    this.krervice.getMessageChange().subscribe(data => this._snackBar.open(data, 'INFO', {duration: 2000}))
  }
  createTable(data: ExamenMedico[]){
    this.dataSource = new MatTableDataSource(data);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  getDisplayedColumns(){
    return this.columnsDefinitions.filter(cd => !cd.hide).map(cd => cd.def);
  }
  openDialog(krentidad?: ExamenMedico){
    this._dialog.open(FormExamenMedicoComponent, {
      width: '750px',
      data: krentidad,
      disableClose: true
    });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  delete(idMedic: number){
    this.krervice.delete(idMedic)
      .pipe(switchMap( ()=> this.krervice.findAll()))
      .subscribe(data => {
        this.krervice.setExamenMedicoChange(data);
        this.krervice.setMessageChange('DELETED!');
      });
  }
}
