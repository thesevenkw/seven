import {Component, Inject, OnInit, ViewChild} from '@angular/core';
import {FormControl, FormGroup, FormsModule, NgForm, ReactiveFormsModule, Validators} from "@angular/forms";
import {NgIf} from "@angular/common";
import {MaterialModule} from "../../../material/material.module";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {switchMap} from "rxjs";
import {ExamenMedico} from "../../../modelo/ExamenMedico";
import {ExamenMedicoService} from "../../../servicio/examen-medico.service";

@Component({
  selector: 'app-form-examen-medico',
  standalone: true,
  imports: [MaterialModule, FormsModule, NgIf, ReactiveFormsModule],
  templateUrl: './form-examen-medico.component.html',
  styleUrl: './form-examen-medico.component.css'
})
export class FormExamenMedicoComponent implements OnInit {
  @ViewChild('ExamenMedicoForm') examenMedicoForm!: NgForm ;
  form: FormGroup;
  constructor(
    @Inject(MAT_DIALOG_DATA) private data: ExamenMedico,
    private krService: ExamenMedicoService,
    private _dialogRef: MatDialogRef<FormExamenMedicoComponent>
  ){}
  ngOnInit(): void {
    if(this.data!==undefined){
      console.log(this.data['resultado']);
      console.log(this.data['observaciones']);
      console.log(this.data['trabajador']);
      console.log(this.data['personal']);

      this.form = new FormGroup({
        idExamenMedico: new FormControl(this.data['idExamenMedico']),
        resultado: new FormControl(this.data['resultado'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        observaciones: new FormControl(this.data['observaciones'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        trabajador: new FormControl(this.data['trabajador'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        personal: new FormControl(this.data['personal'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)])
      });
    }else{
      this.form = new FormGroup({
        idExamenMedico: new FormControl(0),
        resultado: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        observaciones: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        trabajador: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        personal: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)])
      });
    }
  }
  close(){
    this._dialogRef.close();
  }
  operate(){
    const kr: ExamenMedico = new ExamenMedico();
    kr.idExamenMedico = this.form.value['idExamenMedico'];
    kr.resultado = this.form.value['resultado'];
    kr.observaciones = this.form.value['observaciones'];
    kr.trabajador = this.form.value['trabajador'];
    kr.personal = this.form.value['personal'];

    if(this.examenMedicoForm.valid){
      if(kr.idExamenMedico > 0){
        //UPDATE
        this.krService.update(kr.idExamenMedico, kr)
          .pipe(switchMap( ()=> this.krService.findAll() ))
          .subscribe(data => {
            this.krService.setExamenMedicoChange(data);
            this.krService.setMessageChange('UPDATED!');
            this.close();
          });
      }else{
        //INSERT
        this.krService.save(kr)
          .pipe(switchMap( ()=> this.krService.findAll() ))
          .subscribe(data => {
            this.krService.setExamenMedicoChange(data);
            this.krService.setMessageChange('CREATED!');
            this.close();
          });
      }
    }else{
      console.log("Error....")
    }
  }
  get f(){
    return this.form.controls;
  }
}
