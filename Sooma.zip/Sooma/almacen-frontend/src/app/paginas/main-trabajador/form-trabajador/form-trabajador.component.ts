import {Component, Inject, OnInit, ViewChild} from '@angular/core';
import {FormControl, FormGroup, FormsModule, NgForm, ReactiveFormsModule, Validators} from "@angular/forms";
import {NgIf} from "@angular/common";
import {MaterialModule} from "../../../material/material.module";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {switchMap} from "rxjs";
import {Trabajador} from "../../../modelo/Trabajador";
import {TrabajadorService} from "../../../servicio/trabajador.service";

@Component({
  selector: 'app-form-trabajador',
  standalone: true,
  imports: [MaterialModule, FormsModule, NgIf, ReactiveFormsModule],
  templateUrl: './form-trabajador.component.html',
  styleUrl: './form-trabajador.component.css'
})
export class FormTrabajadorComponent implements OnInit {
  @ViewChild('TrabajadorForm') trabajadorForm!: NgForm ;
  form: FormGroup;
  constructor(
    @Inject(MAT_DIALOG_DATA) private data: Trabajador,
    private krService: TrabajadorService,
    private _dialogRef: MatDialogRef<FormTrabajadorComponent>
  ){}
  ngOnInit(): void {
    if(this.data!==undefined){
      console.log(this.data['nombre']);
      console.log(this.data['apellido']);
      console.log(this.data['dni']);
      console.log(this.data['celular']);
      console.log(this.data['cargo']);

      this.form = new FormGroup({
        idTrabajador: new FormControl(this.data['idTrabajador']),
        nombre: new FormControl(this.data['nombre'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        apellido: new FormControl(this.data['apellido'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        dni: new FormControl(this.data['dni'], [Validators.required, Validators.minLength(8), Validators.maxLength(8)]),
        celular: new FormControl(this.data['celular'], [Validators.required, Validators.minLength(9), Validators.maxLength(9)]),
        cargo: new FormControl(this.data['cargo'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)])
      });
    }else{
      this.form = new FormGroup({
        idTrabajador: new FormControl(0),
        nombre: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(70)]),
        apellido: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(70)]),
        dni: new FormControl('', [Validators.required, Validators.minLength(8), Validators.maxLength(8)]),
        celular: new FormControl('', [Validators.required, Validators.minLength(9), Validators.maxLength(9)]),
        cargo: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(70)])
      });
    }
  }
  close(){
    this._dialogRef.close();
  }
  operate(){
    const kr: Trabajador = new Trabajador();
    kr.idTrabajador = this.form.value['idTrabajador'];
    kr.nombre = this.form.value['nombre'];
    kr.apellido = this.form.value['apellido'];
    kr.dni = this.form.value['dni'];
    kr.celular = this.form.value['celular'];
    kr.cargo = this.form.value['cargo'];

    if(this.trabajadorForm.valid){
      if(kr.idTrabajador > 0){
        //UPDATE
        this.krService.update(kr.idTrabajador, kr)
          .pipe(switchMap( ()=> this.krService.findAll() ))
          .subscribe(data => {
            this.krService.setTrabajadorChange(data);
            this.krService.setMessageChange('UPDATED!');
            this.close();
          });
      }else{
        //INSERT
        this.krService.save(kr)
          .pipe(switchMap( ()=> this.krService.findAll() ))
          .subscribe(data => {
            this.krService.setTrabajadorChange(data);
            this.krService.setMessageChange('CREATED!');
            this.close();
          });
      }
    }else{
      console.log("Error....")
    }
  }
  get f(){
    return this.form.controls;
  }
}
