import {Component, Inject, OnInit, ViewChild} from '@angular/core';
import {FormControl, FormGroup, FormsModule, NgForm, ReactiveFormsModule, Validators} from "@angular/forms";
import {NgIf} from "@angular/common";
import {MaterialModule} from "../../../material/material.module";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {switchMap} from "rxjs";
import {Personal} from "../../../modelo/Personal";
import {PersonalService} from "../../../servicio/personal.service";

@Component({
  selector: 'app-form-personal',
  standalone: true,
  imports: [MaterialModule, FormsModule, NgIf, ReactiveFormsModule],
  templateUrl: './form-personal.component.html',
  styleUrl: './form-personal.component.css'
})
export class FormPersonalComponent implements OnInit {
  @ViewChild('PaersonalForm') personalForm!: NgForm ;
  form: FormGroup;
  constructor(
    @Inject(MAT_DIALOG_DATA) private data: Personal,
    private krService: PersonalService,
    private _dialogRef: MatDialogRef<FormPersonalComponent>
  ){}
  ngOnInit(): void {
    if(this.data!==undefined){
      console.log(this.data['nombre']);
      console.log(this.data['apellido']);
      console.log(this.data['especialidad']);
      console.log(this.data['turno']);

      this.form = new FormGroup({
        idPersonal: new FormControl(this.data['idPersonal']),
        nombre: new FormControl(this.data['nombre'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        apellido: new FormControl(this.data['apellido'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        especialidad: new FormControl(this.data['especialidad'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        turno: new FormControl(this.data['turno'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)])
      });
    }else{
      this.form = new FormGroup({
        idPersonal: new FormControl(0),
        nombre: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(70)]),
        apellido: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(70)]),
        especialidad: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(70)]),
        turno: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(70)]),

      });
    }
  }
  close(){
    this._dialogRef.close();
  }
  operate(){
    const kr: Personal = new Personal();
    kr.idPersonal = this.form.value['idPersonal'];
    kr.nombre = this.form.value['nombre'];
    kr.apellido = this.form.value['apellido'];
    kr.especialidad = this.form.value['especialidad'];
    kr.turno = this.form.value['turno'];

    if(this.personalForm.valid){
      if(kr.idPersonal > 0){
        //UPDATE
        this.krService.update(kr.idPersonal, kr)
          .pipe(switchMap( ()=> this.krService.findAll() ))
          .subscribe(data => {
            this.krService.setPersonalChange(data);
            this.krService.setMessageChange('UPDATED!');
            this.close();
          });
      }else{
        //INSERT
        this.krService.save(kr)
          .pipe(switchMap( ()=> this.krService.findAll() ))
          .subscribe(data => {
            this.krService.setPersonalChange(data);
            this.krService.setMessageChange('CREATED!');
            this.close();
          });
      }
    }else{
      console.log("Error....")
    }
  }
  get f(){
    return this.form.controls;
  }
}
