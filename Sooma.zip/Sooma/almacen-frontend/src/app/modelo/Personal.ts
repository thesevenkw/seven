export class Personal {
  idPersonal: number
  nombre: string
  apellido: string
  especialidad: string
  turno: string
}
