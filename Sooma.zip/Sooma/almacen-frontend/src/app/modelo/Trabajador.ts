export class Trabajador {
  idTrabajador: number
  nombre: string
  apellido: string
  dni: string
  celular: string
  cargo: string
}
