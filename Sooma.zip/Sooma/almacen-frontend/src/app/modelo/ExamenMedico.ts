export class ExamenMedico {
  idExamenMedico: number
  resultado: string
  observaciones: string
  trabajador: string
  personal: string
}
