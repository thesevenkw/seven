import { Injectable } from '@angular/core';
import {GenericService} from "./generic.service";
import {BehaviorSubject, Subject} from "rxjs";
import {HttpClient} from "@angular/common/http";
import {environment} from "../../environments/environment.development";
import {Personal} from "../modelo/Personal";

@Injectable({
  providedIn: 'root'
})
export class PersonalService extends GenericService<Personal>{

  protected krubject = new
  BehaviorSubject<Personal[]>([]);
  private messageChange: Subject<string> = new
  Subject<string>;
  constructor(protected override http: HttpClient) {
    super(http, `${environment.HOST}/personales`);
  }
  setPersonalChange(data: Personal[]){
    this.krubject.next(data);
  }
  getPersonalChange(){
    return this.krubject.asObservable();
  }
  setMessageChange(data: string){
    this.messageChange.next(data);
  }
  getMessageChange(){
    return this.messageChange.asObservable();
  }

}
